from diffusion.architectures.simple_convnet import SimpleConvNet
from diffusion.architectures.unet import SimpleUNet