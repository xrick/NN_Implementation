# Speech-To-Phenome
## Description

o Generated phonemes using a model consisting of CNNs and Bidirectional LSTMs with a training set of speech recordings and unaligned phonemes.

o Used CTC Loss.

o Achieving a Levenshtein distance of 7.23 on the test set, convincingly beating the A cutoff of 9.

Dateset available on request.

**Note: This project is part of my Homeworks. Current CMU students please refrain from going through the codes.**
