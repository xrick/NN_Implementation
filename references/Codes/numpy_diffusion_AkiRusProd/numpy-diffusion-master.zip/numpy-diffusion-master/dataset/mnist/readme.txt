For training examples you need to download the datasets from the link: https://pjreddie.com/projects/mnist-in-csv/ and drop them into this folder or run the import_mnist_data script.
