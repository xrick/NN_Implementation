# DataSet
Chinese Corpus:863 Corpus  
- Training set:  
M50		F50		A1-A521  
				AW1-AW129		650 sentences  
M54		F54		B522-B1040  
				BW130-BW259		649 sentences  
M60		F60		C1041-C1560  
				CW260-CW388  	649 sentences  
M64		F64		D1-D625         625 sentences  
- Total:5146 sentences  

Test set:  
M51		F51		A1-A100			100 sentences  
M55		F55		B522-B521		100 sentences  
M61		F61		C1041-C1140		100 sentences  
M63		F63		D1-D100         100 sentences  
Total:800 sentences

# Label   66 phonemes
a 1 ai 2 an 3 ang 4 ao 5 as 6 b 7 c 8 ch 9 d 10  
e 11 ei 12 en 13 eng 14 er 15 es 16 f 17 g 18 h 19 i 20  
ia 21 ian 22 iang 23 iao 24 ie 25 ih 26 in 27 ing 28 iong 29 is 30  
iu 31 iz 32 j 33 k 34 l 35 m 36 n 37 o 38 ong 39 os 40  
ou 41 p 42 q 43 r 44 s 45 sh 46 sil 47 t 48 u 49 ua 50  
uai 51 uan 52 uang 53 ueng 54 ui 55 un 56 uo 57 us 58 v 59 van 60  
ve 61 vn 62 vs 63 x 64 z 65 zh 66  

# Features：
mfcc39   fbank40   spectrum201
