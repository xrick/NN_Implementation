train_cmd="run.pl --mem 6G"
decode_cmd="run.pl --mem 6G"
