KALDI_ROOT=../../kaldi

. $KALDI_ROOT/tools/config/common_path.sh
export LC_ALL=C
